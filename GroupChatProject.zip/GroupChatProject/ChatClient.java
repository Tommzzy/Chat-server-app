import java.io.*;
import java.net.*;
import java.util.Scanner;

public class ChatClient {
    private static final String SERVER_IP = "127.0.0.1";
    private static final int SERVER_PORT = 5555;

    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in);
             Socket socket = new Socket(SERVER_IP, SERVER_PORT)) {
             
            System.out.println("Connected to the chat server");

            System.out.print("Enter your name: ");
            String clientName = scanner.nextLine();

            new Thread(new ReceiveMessages(socket)).start();
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);

            // Send the client's name to the server initially
            out.println(clientName + " has joined the chat!");

            while (true) {
                String message = scanner.nextLine();
                out.println(clientName + ": " + message);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

class ReceiveMessages implements Runnable {
    private final Socket socket;  // mark socket final

    public ReceiveMessages(Socket socket) {
        this.socket = socket;
    }

    @Override
    public void run() {
        try (BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()))) {
            String message;

            while ((message = in.readLine()) != null) {
                System.out.println(message);
            }
        } catch (IOException e) {
            System.err.println("Error in ReceiveMessages: " + e.getMessage());
        }
    }
}
